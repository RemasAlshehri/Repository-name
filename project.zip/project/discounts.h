
#ifndef DISCOUNTS_H
#define DISCOUNTS_H
void fam();
void cat();
double star();
double family(double q);
double kids(double q);
double others(double q);
int feeds(int i);
void pay();


#endif 
