#include <iostream>
#include "discounts.h"
using namespace std;
void cat(){
	cout<<"-----------------------------------------------------------------------"<<endl;
	cout<<"                                 | Entrance fees         |     disount  "<<endl;
	cout<<"------------------------------------------------------------------------"<<endl;
	cout<<"Family                           |      200              |       20%     "<<endl;
	cout<<"------------------------------------------------------------------------"<<endl;
	cout<<"college student at iau           |      200              |       50%   "<<endl;
	cout<<"------------------------------------------------------------------------"<<endl;
	cout<<"Kids                             |      100              |       10%   "<<endl;
	cout<<"------------------------------------------------------------------------"<<endl;
	cout<<"others                           |      200              |    no discount  "<<endl;
	cout<<"-----------------------------------------------------------------------"<<endl;
	
}


void fam(){
	cout<<"\nplease choose from blow (are you a family or a student or .....)\n ";
	cout<<"\na- Family\n";
	cout<<"\nb-A student in iau\n";
	cout<<"\nc-Kids\n  ";
	cout<<"\nd-Others";
	
}
double family(double q){
	int x1;
	
	cout<<"how many people are you?";
	cin>>x1;
	cout<<endl;
	return (x1*(0.2*200)-x1*(-200));
}

double kids(double q){
	int x1;
	
	cout<<"how many people are you?";
	
	cin>>x1;
	cout<<endl;
	return (x1*(100*0.1)-x1*(-100));
}
double others(double q){
	int x1;
	cout<<"how many people are you?";
	
	cin>>x1;
	cout<<endl;
	
	return x1*200;
}
double star(){
	
	double z;
	
	cout<<"\n Did you enjoy it? please  rate us from (1 t0 5): ";
	cin>>z;
	cout<<endl<<endl;
	if(z<=5){
	
	cout<<"thank you for the feedback";
	cout<<endl;	
	}
	else {
		cout<<"invlid number";
		cout<<endl;
}

return z;
		
}
int feeds(int i) {
cout<<"Enter 1 if you want to come here again or 2 if you dont want to come:"<<endl;
cin>>i;

 if(i == 1) {

 cout<<"we are happy for that,welcome again"<<endl;
  return 0;}
 else {
 
 cout<<"sorry we will be better"<<endl;
 return 0;}
 
feeds(i); 

}
void pay(){
	cout<<endl<<endl;
	cout<<"choose your payment method:"<<endl<<endl;
	cout<<"1-Cash"<<endl;
	cout<<"2-Credit Card"<<endl;
}











